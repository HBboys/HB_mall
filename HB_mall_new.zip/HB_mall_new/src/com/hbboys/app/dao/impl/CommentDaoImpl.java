package com.hbboys.app.dao.impl;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hbboys.app.dao.CommentDao;
import com.hbboys.app.domain.Comment;

public class CommentDaoImpl extends HibernateDaoSupport implements CommentDao{

	@Override
	public void newcomment(Comment comment) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(comment);
	}

	@Override
	public void deletecomment(int orderid) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().delete(this.findbyid(orderid));
	}

	@Override
	public List<Comment> myallcomment(int currentPage, int pageSize) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Comment> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				HttpSession session2=ServletActionContext.getRequest().getSession();
				int uid=(int) session2.getAttribute("uid");
				Query query  = session.createQuery("from Comment where order.user.uid=?");
				query.setInteger(0, uid);
				query.setFirstResult((currentPage-1)*pageSize);
				query.setMaxResults(pageSize);
				List<Comment> list = query.list();
				return list;
			}
		});
		return list;
	}

	@Override
	public Comment findbyid(int orderid) {
		// TODO Auto-generated method stub
		return this.getHibernateTemplate().get(Comment.class, orderid);
	}

	@Override
	public int mycommentcount() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Object> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				HttpSession session2=ServletActionContext.getRequest().getSession();
				int uid=(int) session2.getAttribute("uid");
				Query query  = session.createQuery("from Comment where order.user.uid=?");
				query.setInteger(0, uid);
				List<Comment> list = query.list();
				return list;
			}
		});
		Long count=(Long) list.listIterator().next();
		return count.intValue();
	}
}
