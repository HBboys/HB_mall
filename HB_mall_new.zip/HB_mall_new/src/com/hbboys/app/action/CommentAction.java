package com.hbboys.app.action;

import com.hbboys.app.domain.Comment;
import com.hbboys.app.service.CommentService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class CommentAction extends ActionSupport implements ModelDriven<Comment>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Comment comment=new Comment();
	private CommentService commentService;
	private int currentPage=1;
	private int pageSize=5;
	public Comment getComment() {
		return comment;
	}
	public void setComment(Comment comment) {
		this.comment = comment;
	}
	public CommentService getCommentService() {
		return commentService;
	}
	public void setCommentService(CommentService commentService) {
		this.commentService = commentService;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	@Override
	public Comment getModel() {
		// TODO Auto-generated method stub
		return comment;
	}
	public String newcomment() {
		commentService.newcomment(comment);
		return "order_search";
	}
	public String deletecomment() {
		commentService.deletecomment(comment.getOrderid());
		return "order_search";
	}
}
