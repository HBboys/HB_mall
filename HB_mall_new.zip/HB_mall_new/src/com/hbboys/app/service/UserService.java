package com.hbboys.app.service;

import com.hbboys.app.domain.User;

public interface UserService {
	public void register(User user);
}
