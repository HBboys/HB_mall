package com.hbboys.app.service.impl;

import java.util.List;

import com.hbboys.app.dao.CommentDao;
import com.hbboys.app.domain.Comment;
import com.hbboys.app.service.CommentService;
import com.hbboys.app.vo.CommentPage;

public class CommentServiceImpl implements CommentService{
	private CommentDao commentDao;
	public void setCommentDao(CommentDao commentDao) {
		this.commentDao = commentDao;
	}

	@Override
	public void newcomment(Comment comment) {
		// TODO Auto-generated method stub
		commentDao.newcomment(comment);
	}

	@Override
	public void deletecomment(int commentid) {
		// TODO Auto-generated method stub
		commentDao.deletecomment(commentid);
	}

	@Override
	public CommentPage myallcomment(int currentPage, int pageSize) {
		// TODO Auto-generated method stub
		CommentPage commentPage = new CommentPage();
		List<Comment> list = commentDao.myallcomment(currentPage, pageSize);
		commentPage.setDataList(list);
		commentPage.setCurrentPage(currentPage);
		commentPage.setPageSize(pageSize);
		int totalCount = commentDao.mycommentcount();
		commentPage.setTotalCount(totalCount);
		commentPage.setTotalPage(totalCount % pageSize ==0?totalCount/pageSize:totalCount/pageSize+1);
		return commentPage;
	}

}
